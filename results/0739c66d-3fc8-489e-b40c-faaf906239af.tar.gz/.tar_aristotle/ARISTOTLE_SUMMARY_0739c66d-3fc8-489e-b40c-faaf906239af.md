# Summary of changes
## Summary

I worked on filling the `sorry` statements in `AutomatedProofs/JEPA.lean`, a formalization of the "JEPA Learns Influential Features First" result about linear JEPA models learning features in decreasing order of their generalised regression coefficient.

### What was accomplished

The original file had **10 sorry statements** across various lemmas and theorems. I reduced this to **5 sorry statements**, with the following results:

**Fully proved (7 lemmas/theorems):**
1. `gradient_projection` — Key lemma about gradient projection in the generalised eigenbasis. I also corrected a bug in the original formalization (the RHS had an extra `V.mulVec` application that didn't match the mathematical statement).
2. `critical_time_formula` — Critical time formula showing existence of time bounds.
3. `critical_time_ordering` — Higher ρ* implies smaller critical time.
4. `offDiag_ODE` — Off-diagonal ODE bound.
5. `preconditioner_integral_bounded` — Integral of the preconditioner is bounded for L ≥ 2.
6. `preconditioner_integral_diverges_L1` — For L = 1, the integral diverges.
7. `offDiag_bound` (Theorem 7.3) — Off-diagonal amplitude bound via Grönwall-type argument.

**Partially proved (JEPA_rho_ordering, the main theorem):**
- Parts **(C)** Feature ordering existence, **(D)** Depth threshold (vacuously true since L=1 contradicts L≥2), and **(E)** JEPA vs MAE ordering are fully proved.
- Parts **(A)**, **(B)**, **(B')** remain as sorry.

**Remaining sorry statements (5):**
1. `quasiStatic_approx` (Lemma 5.2) — The hypothesis `hV_flow` (non-positive derivative at every point) is insufficient without additional differentiability/continuity assumptions to conclude the function is non-increasing.
2. `diagonal_ODE` (Proposition 6.1) — **Confirmed false** by automated disproof. The statement is under-hypothesized: the given assumptions don't constrain `sigma_r` sufficiently. This is documented in the docstring.
3–5. Parts A, B, B' of `JEPA_rho_ordering` — Depend on the above gaps.

### Other fixes
- Fixed a **toolchain mismatch** (project used v4.29.0-rc6 but Mathlib was built for v4.28.0).
- Fixed multiple **compilation errors** in the original file: `Matrix.dotProduct` → `dotProduct`, removed `ᵀ` postfix notation (not available in this Lean version), added `noncomputable` annotations, replaced `Matrix.IsOrthogonal` with explicit orthogonality conditions, defined `matFrobNorm` to replace missing `Norm` instance for matrices, and fixed the `BalancedInit` structure parameter clash with the implicit variable `d`.
